<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="tileset" tilewidth="64" tileheight="64" spacing="10" tilecount="56" columns="8">
 <image source="../img/tileset.png" width="582" height="508"/>
</tileset>
