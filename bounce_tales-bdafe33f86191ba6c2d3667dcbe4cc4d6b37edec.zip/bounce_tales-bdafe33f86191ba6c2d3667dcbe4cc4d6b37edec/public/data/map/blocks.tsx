<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="blocks" tilewidth="64" tileheight="64" spacing="10" tilecount="48" columns="6">
 <image source="../img/blocks.png" width="434" height="582"/>
 <tile id="0">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0.26434" y="10.3093" width="63.7061" height="53.3968"/>
  </objectgroup>
 </tile>
 <tile id="1">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="20.3542" width="63.9704" height="43.3518"/>
  </objectgroup>
 </tile>
 <tile id="2">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0.528681" y="29.8705" width="63.7061" height="34.0999"/>
  </objectgroup>
 </tile>
 <tile id="39">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0.26434" y="0.528681">
    <polygon points="0,0 63.9704,9.7806 -0.183699,9.15788"/>
   </object>
   <object id="2" x="0.367397" y="10.6545" width="63.1923" height="13.41"/>
  </objectgroup>
 </tile>
</tileset>
