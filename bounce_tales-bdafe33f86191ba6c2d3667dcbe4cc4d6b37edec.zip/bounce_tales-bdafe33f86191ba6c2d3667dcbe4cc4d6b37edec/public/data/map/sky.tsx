<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="sky" tilewidth="64" tileheight="64" tilecount="660" columns="60">
 <image source="../img/background.png" width="3840" height="720"/>
</tileset>
