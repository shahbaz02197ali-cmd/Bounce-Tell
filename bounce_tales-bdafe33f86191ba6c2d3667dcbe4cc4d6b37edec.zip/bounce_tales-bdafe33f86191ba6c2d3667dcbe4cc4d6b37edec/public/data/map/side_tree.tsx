<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="side_tree" tilewidth="64" tileheight="64" tilecount="15" columns="3">
 <image source="../img/side_tree.png" width="192" height="320"/>
</tileset>
